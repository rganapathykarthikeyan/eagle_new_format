const i18nConfig = {
	locales: ['en', 'fr'],
	defaultLocale: 'en'
}

module.exports = i18nConfig

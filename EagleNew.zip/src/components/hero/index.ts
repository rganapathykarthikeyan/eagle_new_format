export * from './hero-content'

import { type PropsWithChildren } from 'react'
import { Header } from '../header'
import { ChatBot } from '../support'
// import { CarBanner } from './car-banner'

export function CarLayout(props: PropsWithChildren) {
	return (
		<section className='relative flex w-full flex-col'>
			<Header />
			{/* <ProgressIndicator /> */}
			{/* <CarBanner /> */}
			<section className='grid flex-grow grid-cols-4 place-content-around px-4 lg:px-12'>
				{/* <div className='sticky right-0 top-10 hidden max-h-[80svh] lg:flex'>
					<Image
						alt='VehicleSketch'
						height={550}
						src={assets.images.vehicleSketch}
						width={500}
					/>
				</div> */}
				<div className='col-span-4 lg:col-span-4'>{props.children}</div>
			</section>
			<div className='fixed bottom-10 right-10'>
				<ChatBot />
			</div>
		</section>
	)
}

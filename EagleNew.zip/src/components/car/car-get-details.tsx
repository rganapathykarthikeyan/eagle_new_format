export function CarGetDetails() {
	return <div></div>
}

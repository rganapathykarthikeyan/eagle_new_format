import { redirect } from 'next/navigation'

export default function Page() {
	redirect('/car-insurance/1')
}

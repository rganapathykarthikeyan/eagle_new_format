import OnboardingMainPage from '@/components/onboard/OnboardingMainPage'

export default function Page() {
	return <OnboardingMainPage />
}

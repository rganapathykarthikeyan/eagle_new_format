import OnboardingInfoPage from '@/components/onboard/OnboardingInfoPage'

export default function Page() {
	return <OnboardingInfoPage />
}

export * from './app.slice'
export * from './car-insurance.slice'
export * from './customer-details.slice'
